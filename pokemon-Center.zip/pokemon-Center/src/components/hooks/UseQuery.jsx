import React from 'react'

const UseQuery = () => {
  return (
    <div>UseQuery</div>
  )
}

export default UseQuery