import React from 'react'

const contextQuery = () => {
  return (
    <div>contextQuery</div>
  )
}

export default contextQuery